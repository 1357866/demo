package com.example.demo.pojo.dto;

import lombok.Data;

@Data
public class StudentPageQueryDTO {


    private String name;

    private String phone;


}
