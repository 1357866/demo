package com.example.demo.pojo.dto;

import lombok.Data;

@Data
public class UserPageQueryDTO {


    private String username;

    private String roleIds;

    private int roles;

}
