package com.example.demo.pojo.dto;

import lombok.Data;

@Data
public class NoticePageQueryDTO {


    private String searchKey;
}
