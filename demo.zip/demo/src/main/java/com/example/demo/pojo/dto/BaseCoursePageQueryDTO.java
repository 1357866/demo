package com.example.demo.pojo.dto;

import lombok.Data;

@Data
public class BaseCoursePageQueryDTO {


    private String coursename;

    private String synopsis;


}
